package Atributos

interface Atributo{
    fun GastarPontos(pontos: Int) : Int
    fun getValue() : Int
    fun addRaca(value: Int)
}

