package Raças

abstract class Raca (var IncrementoForca: Int, var IncrementoDestreza: Int, var IncrementoConstituicao: Int, var IncrementoInteligencia: Int, var IncrementoSabedoria: Int, var IncrementoCarisma: Int, var RacaNome: String ) {
}