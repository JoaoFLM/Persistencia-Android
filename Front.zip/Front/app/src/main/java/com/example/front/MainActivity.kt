package com.example.front

import Atributos.Atributo
import Atributos.Carisma
import Atributos.Constituicao
import Atributos.Destreza
import Atributos.Forca
import Atributos.Inteligencia
import Atributos.Sabedoria
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

public class MainActivity : ComponentActivity() {
    private var Carisma: Carisma = Carisma()
    private var Constituicao: Constituicao = Constituicao()
    private var Destreza: Destreza = Destreza()
    private var Forca: Forca = Forca()
    private var Inteligencia: Inteligencia = Inteligencia()
    private var Sabedoria: Sabedoria = Sabedoria()
    private var pontos: Int = 27

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AtributosScreen(
                Carisma,
                Constituicao,
                Destreza,
                Forca,
                Inteligencia,
                Sabedoria,
                pontos,
            )
        }
    }
}

@Composable
fun AtributosScreen(
    Car: Carisma,
    Con: Constituicao,
    Des: Destreza,
    For: Forca,
    Int: Inteligencia,
    Sab: Sabedoria,
    pontos: Int,
    ) {
    var pontosRestantes by remember { mutableStateOf(pontos) }
    var snackbarVisible by remember { mutableStateOf(false) }
    var snackbarMessage by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Criação de Personagem", fontSize = 18.sp)

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Pontos restantes:", fontSize = 16.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "$pontosRestantes", fontSize = 16.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // colunas
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "Atributo", modifier = Modifier.weight(1f))
            Text(text = "Valor", modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Text(text = "Raça", modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Text(text = "Mod", modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }

        Spacer(modifier = Modifier.height(8.dp))

        AtributoInputRow("Força", For, { pontosRestantes -= it }, { showMessage(it, { snackbarMessage = it; snackbarVisible = true }) })
        Spacer(modifier = Modifier.height(8.dp))
        AtributoInputRow("Destreza", Des, { pontosRestantes -= it }, { showMessage(it, { snackbarMessage = it; snackbarVisible = true }) })
        Spacer(modifier = Modifier.height(8.dp))
        AtributoInputRow("Constituição",  Con, { pontosRestantes -= it }, { showMessage(it, { snackbarMessage = it; snackbarVisible = true }) })
        Spacer(modifier = Modifier.height(8.dp))
        AtributoInputRow("Sabedoria", Sab, { pontosRestantes -= it }, { showMessage(it, { snackbarMessage = it; snackbarVisible = true }) })
        Spacer(modifier = Modifier.height(8.dp))
        AtributoInputRow("Inteligência", Int, { pontosRestantes -= it }, { showMessage(it, { snackbarMessage = it; snackbarVisible = true }) })
        Spacer(modifier = Modifier.height(8.dp))
        AtributoInputRow("Carisma",  Car, { pontosRestantes -= it }, { showMessage(it, { snackbarMessage = it; snackbarVisible = true }) })

        if (snackbarVisible) {
            Snackbar(
                action = {
                    Button(onClick = { snackbarVisible = false }) {
                        Text("Fechar")
                    }
                },
                modifier = Modifier.padding(8.dp)
            ) {
                Text(snackbarMessage)
            }
        }

        Text(text = "PV: ${calculaPV(Con.getValue())}", modifier = Modifier.weight(1f))


        Button(onClick = { }) {
            Text("Salvar atributos")
        }
    }
}

@Composable
fun AtributoInputRow(
    label: String,
    atributo: Atributo,
    updatePontos: (Int) -> Unit,
    onError: (String) -> Unit
) {
    var attValue by remember { mutableStateOf("") }
    var racaValue by remember { mutableStateOf("") }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically // Alinhamento vertical centralizado
    ) {
        // Coluna de Atributos
        Text(text = label, modifier = Modifier.weight(1f))

        // Campo de entrada de número inteiro
        OutlinedTextField(
            value = attValue,
            onValueChange = { newValue ->
                // Permitir apenas números
                if (newValue.all { it.isDigit() }) {
                    attValue = newValue
                }
            },
            keyboardOptions = KeyboardOptions.Default.copy(
                keyboardType = KeyboardType.Number
            ),
            modifier = Modifier
                .weight(1f)
                .width(50.dp)
                .onFocusChanged { focusState ->
                    if (!focusState.isFocused && attValue.isNotEmpty()) {
                        try {
                            val valor = attValue.toInt()
                            updatePontos(atributo.GastarPontos(valor)) // Atualiza os pontos
                        } catch (e: NumberFormatException) {
                            onError("Por favor, insira um número válido.")
                            attValue = "" // Limpa o campo em caso de erro
                        } catch(e: IllegalArgumentException){
                            onError("O valor deve estar entre 8 e 15")
                            attValue = ""
                        }
                    }
                }
        )

        // Coluna Bônus de Raça
        OutlinedTextField(
            value = racaValue,
            onValueChange = { newRaca ->
                // Permitir apenas números
                if (newRaca.all { it.isDigit() }) {
                     racaValue = newRaca
                }
            },
            keyboardOptions = KeyboardOptions.Default.copy(
                keyboardType = KeyboardType.Number
            ),
            modifier = Modifier
                .weight(1f)
                .width(50.dp)
                .onFocusChanged { focusState ->
                    if (!focusState.isFocused && racaValue.isNotEmpty()) {
                        try {
                            val valor = racaValue.toInt()
                            atributo.addRaca(valor)
                        } catch (e: NumberFormatException) {
                            onError("Por favor, insira um número válido.")
                            racaValue = "" // Limpa o campo em caso de erro
                        } catch(e: IllegalArgumentException){
                            onError("O valor deve estar entre -1 e 2")
                            racaValue = ""
                        }
                    }
                }
        )

        // Coluna Mod
        Text(
            text = "${calculaMod(atributo)}",
            modifier = Modifier.weight(1f),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

fun showMessage(message: String, callback: (String) -> Unit) {
    callback(message)
}

fun calculaPV(Constituicao: Int) : Int? {
    val PVbase = 10
    when (Constituicao){
        8 -> return PVbase-1
        9 -> return PVbase-1
        10 -> return PVbase+0
        11 -> return PVbase+0
        12 -> return PVbase+1
        13 -> return PVbase+1
        14 -> return PVbase+2
        15 -> return PVbase+2
        16 -> return PVbase+3
        17 -> return PVbase+3
        18 -> return PVbase+4
        19 -> return PVbase+4
        20 -> return PVbase+5
    }
    return null
}

fun calculaMod(atributo: Atributo) :Int?{
    return when (atributo.getValue()){
        8 -> -1
        9 -> -1
        10 -> 0
        11 -> 0
        12 -> 1
        13 -> 1
        14 -> 2
        15 -> 2
        16 -> 3
        17 -> 3
        18 -> 4
        19 -> 4
        20 -> 5
        else -> {null}
    }
}



